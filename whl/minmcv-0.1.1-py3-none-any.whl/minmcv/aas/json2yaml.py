#!/usr/bin/env python3

import json
import yaml

def build_property(data):
    return {
        "idShort": data.get("idShort"),
        "type": "Property",
        "semanticId": data.get("semanticId"),
        "valueType": data.get("valueType"),
        "value": data.get("value")
    }

def build_multi_language_property(data):
    return {
        "idShort": data.get("idShort"),
        "type": "MultiLanguageProperty",
        "semanticId": data.get("semanticId"),
        "value": data.get("value", [])
    }

def build_entity(data):
    return {
        "idShort": data.get("idShort"),
        "type": "Entity",
        "entityType": data.get("entityType"),
        "statements": [convert_element(stmt) for stmt in data.get("statements", [])]
    }

def build_smc(data):
    return {
        "idShort": data.get("idShort"),
        "type": "SubmodelElementCollection",
        "value": [convert_element(v) for v in data.get("value", [])]
    }

def convert_element(data):
    model_type = data.get("modelType")
    if model_type == "Property":
        return build_property(data)
    elif model_type == "MultiLanguageProperty":
        return build_multi_language_property(data)
    elif model_type == "Entity":
        return build_entity(data)
    elif model_type in ["SubmodelElementCollection", "SubmodelElementList"]:
        return build_smc(data)
    else:
        # fallback: generic dict
        return data

def find_submodel(data):
    if isinstance(data, dict):
        if data.get("modelType") == "Submodel":
            return data
        for v in data.values():
            result = find_submodel(v)
            if result is not None:
                return result
    elif isinstance(data, list):
        for item in data:
            result = find_submodel(item)
            if result is not None:
                return result
    return None

def convert_json_to_yaml(data):
    json_data = find_submodel(data)
    if not json_data:
        raise ValueError("No Submodel found in JSON")

    submodel_yaml = {
        "submodel": {
            "id": json_data.get("id"),
            "idShort": json_data.get("idShort"),
            "semanticId": json_data.get("semanticId"),
            "description": json_data.get("description", []),
            "submodelElements": [convert_element(elem) for elem in json_data.get("submodelElements", [])]
        }
    }

    return yaml.dump(submodel_yaml, sort_keys=False, allow_unicode=True)

def convertFromString(string_data):
    return convert_json_to_yaml(json.loads(string_data))
