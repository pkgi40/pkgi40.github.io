#!/usr/bin/env python3

import json
import yaml

def convert_element_back(elem):
    """Convert YAML element dict back into JSON element with modelType, without unit."""
    etype = elem.get("type")
    if etype == "Property":
        return {
            "modelType": "Property",
            "idShort": elem.get("idShort"),
            "semanticId": elem.get("semanticId"),
            "valueType": elem.get("valueType"),
            "value": elem.get("value")
        }
    elif etype == "MultiLanguageProperty":
        return {
            "modelType": "MultiLanguageProperty",
            "idShort": elem.get("idShort"),
            "semanticId": elem.get("semanticId"),
            "value": elem.get("value", [])
        }
    elif etype == "Entity":
        return {
            "modelType": "Entity",
            "idShort": elem.get("idShort"),
            "entityType": elem.get("entityType"),
            "statements": [convert_element_back(s) for s in elem.get("statements", [])]
        }
    elif etype == "SubmodelElementCollection":
        return {
            "modelType": "SubmodelElementCollection",
            "idShort": elem.get("idShort"),
            "value": [convert_element_back(v) for v in elem.get("value", [])]
        }
    else:
        return elem  # fallback

def convert_yaml_to_json(data):
    """Convert parsed YAML dict into AAS-compliant JSON dict."""
    submodel = data.get("submodel", {})
    return {
        "modelType": "Submodel",
        "id": submodel.get("id"),
        "idShort": submodel.get("idShort"),
        "semanticId": submodel.get("semanticId"),
        "description": submodel.get("description", []),
        "submodelElements": [convert_element_back(e) for e in submodel.get("submodelElements", [])]
    }

def convertFromString(string_data):
    """Entry point: take YAML string, return JSON string."""
    yaml_data = yaml.safe_load(string_data)
    json_data = convert_yaml_to_json(yaml_data)
    return json.dumps(json_data, indent=2, ensure_ascii=False)

