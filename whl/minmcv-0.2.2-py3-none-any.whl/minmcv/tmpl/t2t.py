#!/usr/bin/env python3

from .json2xmi import convert_template_json_to_xmi
from .xmi2json import convert_template_xmi_to_json
from .yaml2json import convert_template_yaml_to_json
from .json2yaml import convert_template_json_to_yaml

def tjson2xmi(iData):
  return convert_template_json_to_xmi(iData)

def txmi2json(iData):
  return convert_template_xmi_to_json(iData)

def tjson2yaml(iData):
  return convert_template_json_to_yaml(iData)

def tyaml2json(iData):
  return convert_template_yaml_to_json(iData)
