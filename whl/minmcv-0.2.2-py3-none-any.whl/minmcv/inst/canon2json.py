#!/usr/bin/env python3

from .canon import *
import json, re


# -----------------------------
# SME converters
# -----------------------------

def element_to_json(elem):
    id_short = clean_id_short(elem.id_short)

    if isinstance(elem, Property):
        # If unit exists → split into Property + PropertyUnit
        if elem.unit:
            return [
                {
                    "modelType": "Property",
                    "idShort": id_short,
                    "valueType": elem.valueType,
                    "value": elem.value
                },
                {
                    "modelType": "Property",
                    "idShort": elem.id_short + "Unit",
                    "valueType": "string",
                    "value": elem.unit
                }
            ]
        else:
            return {
                "modelType": "Property",
                "idShort": id_short,
                "valueType": elem.valueType,
                "value": elem.value
            }

    if isinstance(elem, File):
        return {
            "modelType": "File",
            "idShort": id_short,
            "mimeType": elem.mimeType,
            "value": elem.value
        }

    if isinstance(elem, ReferenceElement):
        return {
            "modelType": "ReferenceElement",
            "idShort": id_short,
            "value": {
                "type": "GlobalReference",
                "keys": [
                    {
                        "type": "GlobalReference",
                        "value": elem.value
                    }
                ]
            }
        }

    if isinstance(elem, RelationshipElement):
        return {
            "modelType": "RelationshipElement",
            "idShort": id_short,
            "value": [
                { "type": "GlobalReference", "value": elem.first },
                { "type": "GlobalReference", "value": elem.second }
            ]
        }

    if isinstance(elem, Range):
        return {
            "modelType": "Range",
            "idShort": id_short,
            "valueType": elem.valueType,
            "min": elem.valueMin,
            "max": elem.valueMax
        }

    if isinstance(elem, MultiLanguageProperty):
        return {
            "modelType": "MultiLanguageProperty",
            "idShort": id_short,
            "value": [
                { "language": "en", "text": elem.value }
            ]
        }

    if isinstance(elem, Operation):
        return {
            "modelType": "Operation",
            "idShort": id_short
        }

    if isinstance(elem, Capability):
        return {
            "modelType": "Capability",
            "idShort": id_short
        }

    if isinstance(elem, SubmodelElementCollection):
        return {
            "modelType": "SubmodelElementCollection",
            "idShort": id_short,
            "value": flatten_elements(elem.value)
        }

    if isinstance(elem, SubmodelElementList):
        return {
            "modelType": "SubmodelElementList",
            "idShort": id_short,
            "value": flatten_elements(elem.value)
        }

    raise ValueError(f"Unsupported element type: {type(elem)}")


def flatten_elements(elems):
    """Because Property with unit returns a list of 2 elements."""
    out = []
    for e in elems:
        js = element_to_json(e)
        if isinstance(js, list):
            out.extend(js)
        else:
            out.append(js)
    return out


# -----------------------------
# Submodel converter
# -----------------------------

#def submodel_to_json(sm: Submodel):
#    return {
#        "modelType": "Submodel",
#        "id": sm.sm_id,
#        "idShort": sm.id_short,
#        "description": [
#            { "language": "en", "text": sm.description }
#        ],
#        "submodelElements": flatten_elements(sm.elements)
#    }

def submodel_to_json(sm: Submodel):
    raw_elems = flatten_elements(sm.elements)

    # 1. Group collections by prefix
    groups = {}
    others = []

    for elem in raw_elems:
        id_short = elem["idShort"]
        prefix, number = split_numbered_id(id_short)

        if prefix and elem["modelType"] == "SubmodelElementCollection":
            groups.setdefault(prefix, []).append(elem)
        else:
            others.append(elem)

    # 2. Convert groups into SubmodelElementList
    for prefix, items in groups.items():
        items_sorted = sorted(items, key=lambda x: int(x["idShort"].split("_")[-1]))
        list_elem = {
            "modelType": "SubmodelElementList",
            "idShort": prefix.capitalize() + "Set",
            "value": items_sorted
        }
        others.append(list_elem)

    return {
        "modelType": "Submodel",
        "id": sm.sm_id,
        "idShort": sm.id_short,
        "description": [
            { "language": "en", "text": sm.description }
        ],
        "submodelElements": others
    }



# -----------------------------
# AssetInformation converter
# -----------------------------

def asset_info_to_json(ai: AssetInformation):
    return {
        "assetKind": ai.assetKind,
        "assetType": ai.assetType,
        "globalAssetId": ai.globalAssetId,
        "defaultThumbnail": {
            "path": ai.defaultThumbnail.path,
            "contentType": ai.defaultThumbnail.contentType
        }
    }


# -----------------------------
# AAS converter
# -----------------------------

def aas_to_json(aas: AssetAdministrationShell):
    return {
        "modelType": "AssetAdministrationShell",
        "id": aas.aas_id,
        "idShort": aas.id_short,
        "assetInformation": asset_info_to_json(aas.assetInformation),
        "submodels": [
            {
                "type": "Submodel",
                "value": sm.id_short
            }
            for sm in aas.submodels
        ]
    }


# -----------------------------
# Full environment converter
# -----------------------------

def convert_canon_to_aas_json(aas: AssetAdministrationShell):
    return json.dumps({
        "assetAdministrationShells": [
            aas_to_json(aas)
        ],
        "submodels": [
            submodel_to_json(sm)
            for sm in aas.submodels
        ]
    }, indent=2)

