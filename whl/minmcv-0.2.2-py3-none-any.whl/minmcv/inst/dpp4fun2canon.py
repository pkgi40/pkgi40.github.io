#!/usr/bin/env python3

from rdflib import Graph, URIRef, Literal
from rdflib.namespace import RDF, RDFS, XSD
from .canon import *

def _local_name(uri: URIRef) -> str:
    s = str(uri)
    if "#" in s:
        return s.split("#")[-1]
    return s.rstrip("/").split("/")[-1]

def _reverse_qudt_unit(unit_uri: URIRef | None) -> str | None:
    if unit_uri is None:
        return None
    local = _local_name(unit_uri)
    for k, v in UNIT.items():
        if v == local:
            return k
    return local

def _infer_value_type(lit: Literal | None) -> str:
    if lit is None:
        return "string"
    dt = lit.datatype
    if dt == XSD.boolean:
        return "boolean"
    if dt in (XSD.integer, XSD.int):
        return "integer"
    if dt in (XSD.decimal, XSD.double, XSD.float):
        return "double"
    if dt in (XSD.dateTime,):
        return "dateTime"
    return "string"

def _literal_to_python(lit: Literal | None):
    if lit is None:
        return None
    dt = lit.datatype
    if dt == XSD.boolean:
        return bool(lit.toPython())
    if dt in (XSD.integer, XSD.int):
        return int(lit.toPython())
    if dt in (XSD.decimal, XSD.double, XSD.float):
        return float(lit.toPython())
    return lit.toPython()

def parse_property_from_info(g: Graph, info_uri: URIRef) -> Property:
    label = g.value(info_uri, RDFS.label)
    if isinstance(label, Literal) and str(label).startswith("property_"):
        parts = str(label).split("_")
        if len(parts) >= 3:
            id_short = "_".join(parts[1:-1])
        else:
            id_short = _local_name(info_uri)
    else:
        id_short = _local_name(info_uri)

    value_lit = g.value(info_uri, DPPO.value)
    unit_node = g.value(info_uri, DPPO.unit)

    if (info_uri, RDF.type, DPPO.ProductCharacteristic) in g:
        unit = _reverse_qudt_unit(unit_node) if isinstance(unit_node, URIRef) else (
            str(unit_node) if isinstance(unit_node, Literal) else None
        )
        value_type = _infer_value_type(value_lit)
        value = _literal_to_python(value_lit)
        return Property(
            id_short=id_short,
            valueType=value_type,
            value=value,
            unit=unit,
        )

    value_type = _infer_value_type(value_lit)
    value = _literal_to_python(value_lit)
    return Property(
        id_short=id_short,
        valueType=value_type,
        value=value,
        unit=None,
    )


def parse_certificate_collection(g: Graph, uri: URIRef) -> SubmodelElementCollection:
    id_short = clean_id_short(_local_name(uri))
    children = []

    desc = g.value(uri, SCHEMA.description)
    if desc is not None:
        children.append(Property(
            id_short="Description",
            valueType="string",
            value=str(desc),
            unit=None
        ))

    issued = g.value(uri, PDTO.hasIssuedDate)
    if issued is not None:
        children.append(Property(
            id_short="IssueDate",
            valueType="dateTime",
            value=str(issued),
            unit=None
        ))

    ident = g.value(uri, SCHEMA.name)
    if ident is not None:
        children.append(Property(
            id_short="Identifier",
            valueType="string",
            value=str(ident),
            unit=None
        ))

    return SubmodelElementCollection(
        id_short=id_short,
        value=children,
        semantic_id=None
    )


def parse_material_collection(g: Graph, uri: URIRef) -> SubmodelElementCollection:
    id_short = clean_id_short(_local_name(uri))
    children = []

    for p, o in g.predicate_objects(uri):
        if p == SCHEMA.name:
            children.append(Property(
                id_short="Name",
                valueType="string",
                value=str(o),
                unit=None
            ))
        elif p == PDTO.isMandatory:
            children.append(Property(
                id_short="Mandatory",
                valueType="boolean",
                value=bool(o.toPython()) if isinstance(o, Literal) else True,
                unit=None
            ))
        elif p == PDTO.hasProductReference and isinstance(o, URIRef):
            children.append(ReferenceElement(
                id_short="MaterialReference",
                value=str(o)
            ))

    return SubmodelElementCollection(
        id_short=id_short,
        value=children,
        semantic_id=None
    )

def parse_instruction_collection(g: Graph, uri: URIRef) -> SubmodelElementCollection:
    id_short = clean_id_short(_local_name(uri))
    children = []

    ident = g.value(uri, SCHEMA.name)
    if ident is not None:
        children.append(Property(
            id_short="Identifier",
            valueType="string",
            value=str(ident),
            unit=None
        ))

    desc = g.value(uri, SCHEMA.description)
    if desc is not None:
        children.append(Property(
            id_short="Description",
            valueType="string",
            value=str(desc),
            unit=None
        ))

    for doc in g.objects(uri, PDTO.InstructionDocument):
        iri = g.value(doc, PDTO.hasIRI)
        if iri is not None:
            children.append(Property(
                id_short="Instruction",
                valueType="string",
                value=str(iri),
                unit=None
            ))

    return SubmodelElementCollection(
        id_short=id_short,
        value=children,
        semantic_id=None
    )

def parse_indicator_collection(g: Graph, uri: URIRef) -> SubmodelElementCollection:
    id_short = clean_id_short(_local_name(uri))
    children = []

    ident = g.value(uri, SCHEMA.name)
    if ident is not None:
        children.append(Property(
            id_short="Identifier",
            valueType="string",
            value=str(ident),
            unit=None
        ))

    desc = g.value(uri, SCHEMA.description)
    if desc is not None:
        children.append(Property(
            id_short="Description",
            valueType="string",
            value=str(desc),
            unit=None
        ))

    val = g.value(uri, DPPO.value)
    if val is not None:
        children.append(Property(
            id_short="Value",
            valueType=_infer_value_type(val),
            value=_literal_to_python(val),
            unit=None
        ))

    unit_node = g.value(uri, DPPO.unit)
    if unit_node is not None:
        unit_str = None
        if isinstance(unit_node, URIRef):
            unit_str = _reverse_qudt_unit(unit_node)
        elif isinstance(unit_node, Literal):
            unit_str = str(unit_node)
        children.append(Property(
            id_short="Unit",
            valueType="string",
            value=unit_str,
            unit=None
        ))

    for doc in g.objects(uri, PDTO.CalculationMethod):
        iri = g.value(doc, PDTO.hasIRI)
        if iri is not None:
            children.append(Property(
                id_short="Method",
                valueType="string",
                value=str(iri),
                unit=None
            ))

    return SubmodelElementCollection(
        id_short=id_short,
        value=children,
        semantic_id=None
    )


def parse_element(g: Graph, uri: URIRef):
    types = set(g.objects(uri, RDF.type))

    if DPPO.ProductCharacteristic in types or DPPO.ProductQuality in types:
        return parse_property_from_info(g, uri)

    if DPPO.CertificateInformation in types:
        return parse_certificate_collection(g, uri)

    if PDTO.MaterialInformation in types:
        return parse_material_collection(g, uri)

    if PDTO.IndicatorInformation in types:
        return parse_indicator_collection(g, uri)

    if PDTO.InstructionInformation in types:
        return parse_instruction_collection(g, uri)

    return parse_property_from_info(g, uri)


#def parse_submodel(g: Graph, sm_uri: URIRef) -> Submodel:
#    local = _local_name(sm_uri)
#    sm_id = local.replace("aspect_", "") if local.startswith("aspect_") else local
#
#    id_short_lit = g.value(sm_uri, SCHEMA.name)
#    id_short = str(id_short_lit) if id_short_lit is not None else sm_id
#
#    desc_lit = g.value(sm_uri, RDFS.comment)
#    description = str(desc_lit) if desc_lit is not None else ""
#
#    elements = []
#    for info_uri in g.objects(sm_uri, PDTO.hasInformation):
#        elem = parse_element(g, info_uri)
#        elements.append(elem)
#
#    return Submodel(
#        sm_id=sm_id,
#        id_short=id_short,
#        description=description,
#        elements=elements,
#        semantic_id=None
#    )

def parse_submodel(g: Graph, sm_uri: URIRef) -> Submodel:
    local = _local_name(sm_uri)
    sm_id = local.replace("aspect_", "") if local.startswith("aspect_") else local

    id_short_lit = g.value(sm_uri, SCHEMA.name)
    id_short = str(id_short_lit) if id_short_lit is not None else sm_id

    desc_lit = g.value(sm_uri, RDFS.comment)
    description = str(desc_lit) if desc_lit is not None else ""

    # --- Collect raw elements ---
    raw = []
    for info_uri in g.objects(sm_uri, PDTO.hasInformation):
        raw.append(parse_element(g, info_uri))

    # --- Group by numbered prefix: Material_00, Material_01 ---
    groups = {}
    others = []

    for elem in raw:
        prefix, number = split_numbered_id(elem.id_short)
        if prefix is not None:
            groups.setdefault(prefix, []).append((number, elem))
        else:
            others.append(elem)

    # --- Build final element list ---
    elements = others

    for prefix, items in groups.items():
        items_sorted = sorted(items, key=lambda x: x[0])
        collections = [elem for _, elem in items_sorted]

        elements.append(
            SubmodelElementList(
                id_short=prefix.capitalize() + "Set",
                value=collections,
                semantic_id=None
            )
        )

    return Submodel(
        sm_id=sm_id,
        id_short=id_short,
        description=description,
        elements=elements,
        semantic_id=None
    )


def parse_asset_information(g: Graph) -> AssetInformation:
  product_uri = None

  for subject in g.subjects(RDF.type,GOODRELATION.ProductOrServiceModel):
    if g.value(subject, RDFS.label) is not None:
      product_uri = subject
    else:
      continue

  label = g.value(product_uri,RDFS.label)
  if product_uri is None and label is None:
    raise ValueError("No valid ProductOrServiceModel found")

  global_id_lit = g.value(product_uri, GOODRELATION.name)
  if global_id_lit is None:
      global_id_lit = g.value(product_uri, SCHEMA.productID)
  
  if global_id_lit is not None:
    global_asset_id = str(global_id_lit)
  else:
    global_asset_id = _local_name(product_uri)  


  desc_lit = g.value(product_uri, SCHEMA.description)
  if desc_lit is not None:
      asset_type = str(desc_lit).replace(global_id_lit,"").strip()
  else:
      asset_type = "Product"

  thumb_path = ""
  thumb_mime = "image/jpeg"
  for img in g.objects(product_uri, PDTO.hasThumbnail):
      iri = g.value(img, PDTO.hasIRI)
      if iri is not None:
          thumb_path = str(iri)
          break

  default_thumbnail = DefaultThumbnail(
      path=thumb_path,
      contentType=thumb_mime
  )

  return AssetInformation(
      assetKind="Instance",
      assetType=asset_type,
      globalAssetId=global_asset_id,
      defaultThumbnail=default_thumbnail
  )


def parse_aas(g: Graph) -> AssetAdministrationShell:
    aas_uri = None
    for s in g.subjects(RDF.type, PDTO.InformationModel):
        aas_uri = s
        break
    if aas_uri is None:
        raise ValueError("No PDTO.InformationModel found")

    local = _local_name(aas_uri)
    aas_id = local.replace("information_model_", "") if local.startswith("information_model_") else local

    label_lit = g.value(aas_uri, RDFS.label)
    if label_lit is not None:
        parts = str(label_lit).split("_")
        if len(parts) >= 3:
            id_short = "_".join(parts[2:-1])
        else:
            id_short = aas_id
    else:
        id_short = aas_id

    asset_info = parse_asset_information(g)

    submodels = []
    for sm_uri in g.objects(aas_uri, PDTO.modelAggregatedFrom):
        submodels.append(parse_submodel(g, sm_uri))

    return AssetAdministrationShell(
        aas_id=aas_id,
        id_short=id_short,
        assetInformation=asset_info,
        submodels=submodels,
        semantic_id=None
    )

def convert_dpp4fun_to_canon(data: str) -> AssetAdministrationShell:
  g = Graph()
  g.parse(data=data,format="xml")
  return parse_aas(g)

