#!/usr/bin/env python3

from .canon import *
from rdflib import Graph, Namespace, URIRef, Literal
from rdflib.namespace import RDF, XSD, OWL, RDFS
import random, string

def convert_property(g:Graph,prop:Property,base:str) -> URIRef | None:
  if not isinstance(prop, Property):
    return None

  random_prop_id = ''.join(random.choices(string.ascii_letters + 
                                             string.digits,k=6))
  info_uri = URIRef(base + "property_" + random_prop_id)
  g.add((info_uri,RDFS.label,Literal("property_" + 
    "_".join(prop.id_short.lower().split())) + "_" + random_prop_id))
  g.add((info_uri,RDFS.comment,Literal("Property of " 
    + " ".join(prop.id_short.split())) + " with ID " + random_prop_id))

  try:
    clarified = DPP4FUN[prop.id_short.lower()]
  except Exception:
    clarified = DPP4FUN.GenericProperty

  if prop.unit and prop.unit not in ["null", None]:
    g.add((info_uri,RDF.type,DPPO.ProductCharacteristic))

    if isinstance(prop.value,(int,float)):
      g.add((info_uri,DPPO.value,Literal(prop.value,datatype=XSD.decimal)))
    else:
      g.add((info_uri,DPPO.value,Literal(prop.value)))

    qudt_unit = UNIT.get(prop.unit,None)
    if qudt_unit:
      g.add((info_uri,DPPO.unit,QUDT[qudt_unit]))
    else:
      g.add((info_uri,DPPO.unit,Literal(prop.unit)))
  else:
    g.add((info_uri,RDF.type,DPPO.ProductQuality))
    g.add((info_uri,DPPO.value,Literal(prop.value)))

  g.add((info_uri,PDTO.clarifiedProperty,clarified))
  return info_uri

def convert_certificate(g:Graph,smc:SubmodelElementCollection,
                        base:str) -> URIRef | None:

  random_certificate_id = ''.join(random.choices(string.ascii_letters 
                                         + string.digits,k=6))
  certificate_uri = URIRef(base + smc.id_short.lower() + "_" + 
                           random_certificate_id)

  g.add((certificate_uri,RDF.type,DPPO.CertificateInformation))
  for child in smc.value:
    if not isinstance(child,Property):
      continue
    
    if "description" in child.id_short.lower():
      g.add((certificate_uri,SCHEMA.description,Literal(child.value,
                                                        datatype=XSD.string)))
    elif "issuedate" in child.id_short.lower():
      g.add((certificate_uri,PDTO.hasIssuedDate,Literal(child.value,
                                                        datatype=XSD.dateTime)))
    elif "identifier" in child.id_short.lower():
      g.add((certificate_uri,SCHEMA.name,Literal(child.value,
                                                 datatype=XSD.string)))
      g.add((certificate_uri,RDFS.label,Literal("Certificate_" + 
        "_".join(child.value.split())) + "_" + random_certificate_id))
      g.add((certificate_uri,RDFS.comment,Literal("Certificate information of " 
        + " ".join(child.value.split())) + "with ID " + random_certificate_id))

  return certificate_uri

def convert_material(g:Graph,smc:SubmodelElementCollection,
                        base:str) -> URIRef | None:

  random_material_id = ''.join(random.choices(string.ascii_letters 
                                         + string.digits,k=6))
  material_uri = URIRef(base + smc.id_short.lower() + "_" +
                        random_material_id)

  g.add((material_uri,RDF.type,PDTO.MaterialInformation))

  for child in smc.value:
    if "name" in child.id_short.lower():
      g.add((material_uri,SCHEMA.name,Literal(child.value,
                                                 datatype=XSD.string)))
      g.add((material_uri,RDFS.label,Literal("Material_" + 
        "_".join(child.value.split())) + "_" + random_material_id))
      g.add((material_uri,RDFS.comment,Literal("Material information of " + 
        " ".join(child.value.split())) + " with ID " + random_material_id))
    elif "mandatory" in child.id_short.lower():
      g.add((material_uri,PDTO.isMandatory,Literal(child.value,
                                                        datatype=XSD.boolean)))
    elif "materialreference" in child.id_short.lower():
      product_uri = URIRef(child.value) 
      g.add((product_uri,RDF.type,GOODRELATION.ProductOrServiceModel))
      g.add((material_uri,PDTO.hasProductReference,product_uri))
        
  return material_uri

def convert_indicator(g:Graph,smc:SubmodelElementCollection,
                        base:str) -> URIRef | None:

  random_indicator_id = ''.join(random.choices(string.ascii_letters 
                                         + string.digits,k=6))
  indicator_uri = URIRef(base + smc.id_short.lower() + "_" + 
                         random_indicator_id)

  g.add((indicator_uri,RDF.type,PDTO.IndicatorInformation))

  for child in smc.value:
    if not isinstance(child,Property):
      continue
    
    if "identifier" in child.id_short.lower():
      g.add((indicator_uri,SCHEMA.name,Literal(child.value,
                                                 datatype=XSD.string)))
      g.add((indicator_uri,RDFS.label,Literal("Indicator_"
                                              + "_".join(child.value.split()) 
                                              + "_" + random_indicator_id)))
      g.add((indicator_uri,RDFS.comment,Literal("Indicator" 
                                                + " ".join(child.value.split())
                                                + "with ID "
                                                + random_indicator_id)))
    elif "description" in child.id_short.lower():
      g.add((indicator_uri,SCHEMA.description,Literal(child.value,
                                                        datatype=XSD.string)))
    elif "value" in child.id_short.lower():
      g.add((indicator_uri,DPPO.value,Literal(child.value)))
    elif "unit" in child.id_short.lower():
      qudt_unit = UNIT.get(child.value,None)

      if qudt_unit:
        g.add((indicator_uri,DPPO.unit,QUDT[qudt_unit]))
      else:
        unit_uri = URIRef(base + ''.join(child.value.split()))
        g.add((unit_uri,RDF.type,DPPO.Unit))
        g.add((indicator_uri,DPPO.unit,unit_uri))
    elif "method" in child.id_short.lower():
      random_doc_id = ''.join(random.choices(string.ascii_letters 
                                             + string.digits,k=6))
      document_uri = URIRef(base + "digitaldocument_" + random_doc_id)
      g.add((document_uri,RDFS.label,Literal("document_" + random_doc_id)))
      g.add((document_uri,RDFS.comment,Literal("Calculation method with ID "
                                               + random_doc_id)))
      g.add((document_uri,RDF.type,SCHEMA.DigitalDocument))
      g.add((document_uri,PDTO.hasIRI,Literal(child.value)))
      g.add((indicator_uri,PDTO.CalculationMethod,document_uri))
  return indicator_uri

def convert_element(g: Graph,parent_uri:URIRef,elem,base:str) -> None:
  if isinstance(elem, Property):
    property_uri = convert_property(g,elem,base)
    if property_uri is not None:
      g.add((parent_uri,PDTO.hasInformation,property_uri))
      
  elif isinstance(elem, SubmodelElementCollection):
    if "certificate_" in elem.id_short.lower(): 
      certificate_uri = convert_certificate(g,elem,base)
      g.add((parent_uri,PDTO.hasInformation,certificate_uri))
    elif "material_" in elem.id_short.lower():
      material_uri = convert_material(g,elem,base)
      g.add((parent_uri,PDTO.hasInformation,material_uri))
    elif "indicator_" in elem.id_short.lower():
      indicator_uri = convert_indicator(g,elem,base)
      g.add((parent_uri,PDTO.hasInformation,indicator_uri))
    else:
      for child in elem.value:
        convert_element(g, parent_uri, child, base)

  elif isinstance(elem, SubmodelElementList):
    for child in elem.value:
      convert_element(g, parent_uri, child, base)

#def convert_canon_to_owl(aas_obj:AssetAdministrationShell,filename,
#                         base:str="https://cir4fun.eu/data#",path:str="./"):
def convert_canon_to_owl(aas_obj:AssetAdministrationShell,
                         base:str="https://cir4fun.eu/data#"):

  g = Graph()
  g.bind("aas",AAS)
  g.bind("dppo",DPPO)
  g.bind("pdto",PDTO)
  g.bind("qudt",QUDT)
  g.bind("rdfs",RDFS)
  g.bind("dpp4fun",DPP4FUN)

  ontology_iri = URIRef(base + "test")
  g.add((ontology_iri,RDF.type,OWL.Ontology))
  g.add((ontology_iri,OWL.imports,
         URIRef("http://www.aidimme.es/FurnitureSectorOntology.owl")))
  g.add((ontology_iri,OWL.imports,
         URIRef("http://www.w3id.org/pdto/0.9.1")))
  g.add((ontology_iri,OWL.imports,
         URIRef("https://www.cir4fun.eu/ontology/dpp4fun/0.0.4")))

  g.add((PDTO.modelAggregatedFrom,RDF.type,OWL.ObjectProperty))
  g.add((PDTO.hasInformation,RDF.type,OWL.ObjectProperty))
  g.add((PDTO.clarifiedProperty,RDF.type,OWL.ObjectProperty))
  g.add((DPPO.unit,RDF.type,OWL.ObjectProperty))
  g.add((DPPO.value,RDF.type,OWL.DatatypeProperty))
  g.add((PDTO.hasSimpleValue,RDF.type,OWL.DatatypeProperty))

  
  aas_uri = URIRef(base + "information_model_" + aas_obj.aas_id)
  g.add((aas_uri,RDF.type,PDTO.InformationModel))
  g.add((aas_uri,RDFS.label,Literal("Information_Model_" + 
    "_".join(aas_obj.id_short.split()) + "_" + aas_obj.aas_id)))
  g.add((aas_uri,RDFS.comment,Literal("Information model of " + 
    " ".join(aas_obj.id_short.split()) + " with ID " + aas_obj.aas_id)))
 
  asset = aas_obj.assetInformation
  asset_uri = URIRef(base + "product_" + aas_obj.aas_id) 
  digi_asset_uri = URIRef(base + "digital_product_" + aas_obj.aas_id) 

  g.add((asset_uri,RDFS.label,Literal("Product_" + 
    "_".join(asset.globalAssetId.split()) + "_" + aas_obj.aas_id)))
  g.add((asset_uri,SCHEMA.description,Literal(
    " ".join(asset.assetType.split()) + " " +  asset.globalAssetId)))
  g.add((asset_uri,RDFS.comment,Literal("Product instance of " + 
    " ".join(asset.assetType.split()) + " with ID " + aas_obj.aas_id)))
  g.add((asset_uri,RDF.type,GOODRELATION.ProductOrServiceModel))
  g.add((asset_uri,GOODRELATION.name,
         Literal('_'.join(asset.globalAssetId.split()))))
  g.add((asset_uri,SCHEMA.productID,
         Literal(''.join(aas_obj.aas_id))))

  random_thumbnail_id = ''.join(random.choices(string.ascii_letters 
                                         + string.digits,k=6))
  image_uri = URIRef(base + "thumbnail_" + random_thumbnail_id)
  g.add((image_uri,RDF.type,SCHEMA.ImageObject))
  g.add((image_uri,PDTO.hasIRI,Literal(asset.defaultThumbnail.path)))
  g.add((asset_uri,PDTO.hasThumbnail,image_uri))
  g.add((image_uri,RDFS.label,Literal("thumbnail_" 
                                      + ''.join(asset.globalAssetId.split())
                                      + '_' + random_thumbnail_id)))
  g.add((image_uri,RDFS.comment,Literal("Reduced image of " + 
    " ".join(asset.assetType.split()) + " with ID " + random_thumbnail_id)))

  for sm in aas_obj.submodels:
    sm_uri = URIRef(base + "aspect_" + sm.sm_id)

    try:
      sm_class = SUBMODEL.get(sm.id_short,PDTO.ApsectModel)
    except Exception:
      sm_class = PDTO.AspectModel

    g.add((sm_uri,RDF.type,sm_class))
    g.add((aas_uri,PDTO.modelAggregatedFrom,sm_uri))

    g.add((sm_uri,SCHEMA.name,Literal(sm.id_short,datatype=XSD.string)))
    g.add((sm_uri,RDFS.label,Literal("Submodel_" + 
      "_".join(sm.id_short.split()) + "_" + sm.sm_id)))
    g.add((sm_uri,RDFS.comment,Literal("Submodel instance of " + 
      " ".join(asset.assetType.split()) + " with ID " + sm.sm_id)))

    for elem in sm.elements:
      convert_element(g,sm_uri,elem,base)

  dpp_uri = URIRef(base + "dpp_" + aas_obj.aas_id)
  g.add((dpp_uri,RDF.type,DPP4FUN.DigitalProductPassport))
  g.add((dpp_uri,DTW.hasPhysicalEntity,asset_uri))
  g.add((dpp_uri,DTW.hasDigitalEntity,digi_asset_uri))
  g.add((digi_asset_uri,RDFS.label,Literal("Digital_product_" + 
    "_".join(asset.globalAssetId.split()) + "_" + aas_obj.aas_id)))
  g.add((digi_asset_uri,RDFS.comment,Literal("Digital Product instance of " + 
    " ".join(asset.assetType.split()) + " with ID " + asset.globalAssetId)))
  # Carefull
  g.add((digi_asset_uri,DTW.hasModel,aas_uri))
  g.add((dpp_uri,RDFS.label,Literal("DPP_" + 
    "_".join(asset.globalAssetId.split()) + "_" + aas_obj.aas_id)))
  g.add((dpp_uri,RDFS.comment,Literal("Digital Product Passport instance of " + 
    " ".join(asset.assetType.split()) + " with ID " + asset.globalAssetId)))

  #g.serialize(destination=(path + "/" + filename + ".owl"),format="xml")
  owl_data = g.serialize(format="xml")
  return owl_data
