#!/usr/bin/env python3

import xml.etree.ElementTree as ET
import xml.dom.minidom

from .canon import *

# ---------------------------------------------------------
# XMI BUILDERS (aligned with your JSON → XMI file)
# ---------------------------------------------------------

def build_langstring(description):
    langstring = ET.Element('AAS:LangString')
    langstring.set('value', description['text'])
    return langstring

def build_property(iId, iDescription):
    elem = ET.Element('AAS:Property')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_operation(iId, iDescription):
    elem = ET.Element('AAS:Operation')
    elem.set('xmi:id', iId)
    elem.set('base_Operation', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_file(iId, iDescription, iMimeType):
    elem = ET.Element('AAS:File')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")
    elem.set('mime_Type', f"{iMimeType}")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_range(iId, iDescription, iMin, iMax):
    elem = ET.Element('AAS:Range')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")
    elem.set('min', f"{iMin}")
    elem.set('max', f"{iMax}")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_multi_language_property(iId, iDescription):
    elem = ET.Element('AAS:MultiLanguageProperty')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_reference(iId, iDescription):
    elem = ET.Element('AAS:Property')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_entity(iId, iDescription):
    elem = ET.Element('AAS:Entity')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_capability(iId, iDescription):
    elem = ET.Element('AAS:Capability')
    elem.set('xmi:id', iId)
    elem.set('base_Property', f"{iId}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": iDescription}))
    return elem

def build_smc(smc_id, smc_description):
    elem = ET.Element('AAS:SubmodelElementCollection')
    elem.set('xmi:id', smc_id)
    elem.set('base_Class', f"{smc_id}_base")
    elem.set('base_HasKind_Class', f"{smc_id}_base")
    elem.set('base_HasSemantics_Class', f"{smc_id}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": smc_description}))
    return elem

def build_sm(sm_id_short, sm_description):
    elem = ET.Element('AAS:Submodel')
    elem.set('xmi:id', sm_id_short)
    elem.set('base_Class', f"{sm_id_short}_base")
    elem.set('base_HasKind_Class', f"{sm_id_short}_base")
    elem.set('base_HasSemantics_Class', f"{sm_id_short}_base")

    description = ET.SubElement(elem, 'description')
    description.append(build_langstring({"text": sm_description}))
    return elem

# ---------------------------------------------------------
# CANONICAL → "modelType" mapping
# ---------------------------------------------------------

def _elem_model_type(elem):
    if isinstance(elem, SubmodelElementCollection):
        return "SubmodelElementCollection"
    if isinstance(elem, SubmodelElementList):
        return "SubmodelElementList"
    if isinstance(elem, Property):
        return "Property"
    if isinstance(elem, Operation):
        return "Operation"
    if isinstance(elem, File):
        return "File"
    if isinstance(elem, Range):
        return "Range"
    if isinstance(elem, MultiLanguageProperty):
        return "MultiLanguageProperty"
    if isinstance(elem, ReferenceElement):
        return "ReferenceElement"
    if isinstance(elem, Entity):
        return "Entity"
    if isinstance(elem, Capability):
        return "Capability"
    return "Unknown"

# ---------------------------------------------------------
# Recursive classifier builder (aligned with build_nest_classifier)
# ---------------------------------------------------------

def build_nest_classifier_from_canon(elems, parent, elem, level=0, sml_id=None):
    model_type = _elem_model_type(elem)
    child_id = elem.id_short if sml_id is None else sml_id
    child_dp = ""  # canonical elements have no description field in your model

    # --- SubmodelElementCollection ---
    if model_type == 'SubmodelElementCollection':
        child = ET.SubElement(parent, 'nestedClassifier')
        child.set('xmi:type', 'uml:Class')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_smc(child_id, child_dp))

        for value in elem.value:
            build_nest_classifier_from_canon(elems, child, value, level+1)

    # --- SubmodelElementList ---
    elif model_type == 'SubmodelElementList':
        child = ET.SubElement(parent, 'nestedClassifier')
        child.set('xmi:type', 'uml:Class')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_smc(child_id, child_dp))

        for value in elem.value:
            build_nest_classifier_from_canon(
                elems,
                child,
                value,
                level+1,
                child_id.replace('Set', '_00')
            )

    # --- Property ---
    elif model_type == 'Property':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_property(child_id, child_dp))

        # Option A: if unit exists → create extra AAS:Property "<idShort>Unit"
        if getattr(elem, "unit", None):
            unit_id = f"{child_id}Unit"
            elems.append(build_property(unit_id, ""))

    # --- Operation ---
    elif model_type == 'Operation':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Operation')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_operation(child_id, child_dp))

    # --- File ---
    elif model_type == 'File':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        # no mimeType info in canonical here → empty description
        elems.append(build_file(child_id, child_dp, ""))

    # --- Range ---
    elif model_type == 'Range':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        # no min/max in this mapping → keep empty
        elems.append(build_range(child_id, child_dp, "", ""))

    # --- MultiLanguageProperty ---
    elif model_type == 'MultiLanguageProperty':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_multi_language_property(child_id, child_dp))

    # --- ReferenceElement ---
    elif model_type == 'ReferenceElement':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_reference(child_id, child_dp))

        type_elem = ET.SubElement(child, 'type')
        type_elem.set('xmi:type', 'uml:PrimitiveType')
        type_elem.set(
            'href',
            'pathmap://UML_LIBRARIES/XMLPrimitiveTypes.library.uml#AnyURI'
        )

    # --- Entity ---
    elif model_type == 'Entity':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_entity(child_id, child_dp))

    # --- Capability ---
    elif model_type == 'Capability':
        child = ET.SubElement(parent, 'ownedAttribute')
        child.set('xmi:type', 'uml:Property')
        child.set('xmi:id', f"{child_id}_base")
        child.set('name', child_id)
        elems.append(build_capability(child_id, child_dp))

# ---------------------------------------------------------
# MAIN ENTRY POINT (aligned with convert_json_to_xmi)
# ---------------------------------------------------------

def convert_canon_to_aas_xmi(aas: AssetAdministrationShell) -> str:
    """
    Mirror of convert_json_to_xmi, but starting from a canonical AAS.
    It takes the FIRST Submodel in aas.submodels, like find_submodel().
    """
    if not aas.submodels:
        raise ValueError("AAS has no submodels")

    sm: Submodel = aas.submodels[0]
    elems = []

    xmi = ET.Element('xmi:XMI', {
        'xmi:version': '20131001',
        'xmlns:xmi': 'http://www.omg.org/spec/XMI/20131001',
        'xmlns:AAS': 'http://www.eclipse.org/papyrus/AAS',
        'xmlns:uml': 'http://www.eclipse.org/uml2/5.0.0/UML',
        'xmlns:ecore': 'http://www.eclipse.org/emf/2002/Ecore',
        'xmlns:standard': 'http://www.eclipse.org/uml2/5.0.0/UML/Profile/Standard'
    })

    model_id = 'cea'
    sm_id = sm.sm_id

    model = ET.SubElement(xmi, 'uml:Model', {
        'URI': f"{sm_id}",
        'xmi:id': f"{model_id}_base",
        'name': 'CEA'
    })

    sm_id_short = sm.id_short
    sm_dp = sm.description or ""

    sm_class = ET.SubElement(model, 'packagedElement', {
        'xmi:type': 'uml:Class',
        'xmi:id': f"{sm_id_short}_base",
        'name': sm_id_short
    })
    elems.append(build_sm(sm_id_short, sm_dp))

    for submodelElement in sm.elements:
        build_nest_classifier_from_canon(elems, sm_class, submodelElement)

    for elem in elems:
        xmi.append(elem)

    tree = ET.ElementTree(xmi)
    reparsed = xml.dom.minidom.parseString(ET.tostring(tree.getroot(), 'utf-8'))
    return reparsed.toprettyxml(indent="  ")

