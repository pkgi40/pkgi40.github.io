#!/usr/bin/env python3

from .canon import *
from .canon2dpp4fun import convert_canon_to_dpp4fun
from .dpp4fun2canon import convert_dpp4fun_to_canon
from .canon2json import convert_canon_to_aas_json
from .json2canon import convert_aas_json_to_canon
from .canon2yaml import convert_canon_to_aas_yaml
from .yaml2canon import convert_aas_yaml_to_canon
from .canon2xmi import convert_canon_to_aas_xmi

def json2yaml(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_aas_yaml(tCanon)

def yaml2json(iData):
  tCanon = convert_aas_yaml_to_canon(iData)
  return convert_canon_to_aas_json(tCanon)

def json2xmi(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_aas_xmi(tCanon)
    
def xmi2json(iData):
  print("TODO")

def json2uml():
  print("TODO")

def uml2json():
  print("TODO")

def xmi2uml():
  print("TODO")

def uml2xmi():
  print("TODO")

def xmi2yaml(iData):
  print("TODO")

def yaml2xmi(iData):
  print("TODO")

def uml2yaml(iData):
  print("TODO")

def yaml2uml(iData):
  print("TODO")





