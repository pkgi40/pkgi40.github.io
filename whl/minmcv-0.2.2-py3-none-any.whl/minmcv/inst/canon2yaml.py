#!/usr/bin/env python3

import yaml, re
from .canon import *

#def clean_id_short(id_short: str) -> str:
#  m = re.match(r"^(.*?_\d+)(?:_[A-Za-z0-9]+)$", id_short)
#  if m:
#    id_short =  m.group(1)
#  id_short = id_short[0].upper() + id_short[1:]
#  return id_short
#
#def split_numbered_id(id_short: str):
#  m = re.match(r"^(.*)_(\d+)$", id_short)
#  if m:
#    return m.group(1), int(m.group(2))
#  return None, None

def element_to_yaml(elem):
  id_short = clean_id_short(elem.id_short)
  
  if isinstance(elem, Property):
      base = {id_short: elem.value}
      if elem.unit:
          base[id_short + "Unit"] = elem.unit
      return base

  if isinstance(elem, File):
      return {id_short: elem.value}

  if isinstance(elem, ReferenceElement):
      return {elem.id_short: elem.value}

  if isinstance(elem, RelationshipElement):
      return {
          elem.id_short: {
              "first": elem.first,
              "second": elem.second
          }
      }

  if isinstance(elem, Range):
      out = {
          elem.id_short: {
              "min": elem.valueMin,
              "max": elem.valueMax
          }
      }
      if elem.unit:
          out[elem.id_short]["Unit"] = elem.unit
      return out

  if isinstance(elem, MultiLanguageProperty):
    return {elem.id_short: elem.value}

  if isinstance(elem, SubmodelElementCollection):
    block = {}
    for child in elem.value:
      child_yaml = element_to_yaml(child)
      for k, v in child_yaml.items():
        block[k] = v
    return {id_short: block}

  ## ---------- SubmodelElementList ----------
  #if isinstance(elem, SubmodelElementList):
  #  lst = []
  #  for child in elem.value:
  #    lst.append(element_to_yaml(child))
  #  return {elem.id_short: lst}

  #raise ValueError(f"Unsupported SME type: {type(elem)}")
  
  # ---------- SubmodelElementList ----------
  if isinstance(elem, SubmodelElementList):
      block = {}
      all_collections = True
  
      for child in elem.value:
          child_yaml = element_to_yaml(child)
  
          if len(child_yaml) == 1:
              k, v = next(iter(child_yaml.items()))
              block[k] = v
          else:
              all_collections = False
  
      if all_collections:
          return {elem.id_short: block}
  
      lst = []
      for child in elem.value:
          lst.append(element_to_yaml(child))
      return {elem.id_short: lst}

def submodel_to_yaml(sm: Submodel):
    block = {
        "Identifier": sm.sm_id,
        "IdShort": sm.id_short
    }

    raw_items = []
    for elem in sm.elements:
      raw_items.append(element_to_yaml(elem))

    groups = {}
    others = {}

    for item in raw_items:
        for id_short, value in item.items():

            if isinstance(value, dict):
                prefix, number = split_numbered_id(id_short)
                if prefix:
                    groups.setdefault(prefix, []).append((number, {id_short: value}))
                    continue

            others[id_short] = value

    for k, v in others.items():
      block[k] = v

    for prefix, items in groups.items():
        items_sorted = sorted(items, key=lambda x: x[0])
        block[prefix.capitalize() + "Set"] = [v for _, v in items_sorted]

    return block

def asset_info_to_yaml(ai: AssetInformation):
  return {
    "assetKind": ai.assetKind,
    "assetType": ai.assetType,
    "globalAssetId": ai.globalAssetId,
    "image": ai.defaultThumbnail.path
  }


def aas_to_yaml(aas: AssetAdministrationShell):
  out = {
    "Identifier": aas.aas_id,
    "IdShort": aas.id_short,
    "AssetInformation": asset_info_to_yaml(aas.assetInformation),
    "Submodels": []
  }

  for sm in aas.submodels:
    out["Submodels"].append(submodel_to_yaml(sm))

  return out

def convert_canon_to_aas_yaml(aas: AssetAdministrationShell) -> str:
  data = aas_to_yaml(aas)
  return yaml.dump(data, sort_keys=False, allow_unicode=True)
