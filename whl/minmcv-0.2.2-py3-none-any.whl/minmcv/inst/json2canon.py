#!/usr/bin/env python3

from .canon import *
import json

def parse_element_with_unit(data,unit):
  return Property(
    id_short=data.get("idShort"),
    valueType=data.get("valueType"),
    value=data.get("value"),
    unit=unit.get("value")
  )

def parse_element(data):
  model_type = data.get("modelType")
  id_short = data.get("idShort")

  if model_type == "Entity":
    return

  if model_type == "Property":
      return Property(
          id_short=id_short,
          valueType=data.get("valueType"),
          value=data.get("value"),
          unit=data.get("unit")
      )

  if model_type == "Operation":
      return Operation(
          id_short=id_short
      )

  if model_type == "Capability":
      return Capability(
          id_short=id_short
      )
  
  if model_type == "File":
      return File(
          id_short=id_short,
          mimeType=data.get("mimeType"),
          value=data.get("value", "")
      )

  if model_type == "RelationshipElement":
      return RelationshipElement(
          id_short=id_short,
          first=data.get("value", [{}])[0].get("value", ""),
          second=data.get("value", [{}])[0].get("value", "")
      )
 
  if model_type == "Range":
      return Range(
          id_short=id_short,
          valueType=data.get("valueType"),
          valueMin=data.get("min"),
          valueMax=data.get("max")
      )

  if model_type == "MultiLanguageProperty":
    return MultiLanguageProperty( 
        id_short=id_short,
        value=data.get("value",[{}])[0].get("text", "")
    )

  if model_type == "ReferenceElement":
    return ReferenceElement( 
        id_short=id_short,
        value=data.get("value")["keys"][0]["value"]
    )
  
  if model_type == "SubmodelElementCollection":
      smc = SubmodelElementCollection(id_short=id_short)
      for child in data.get("value", []):
          smc.value.append(parse_element(child))
      return smc
  
  if model_type == "SubmodelElementList":
      sml = SubmodelElementList(id_short=id_short)
      for child in data.get("value", []):
          sml.value.append(parse_element(child))
      return sml
  
  raise ValueError(f"Unsupported modelType: {model_type}")

def parse_submodel(data):
  if data.get("modelType") != "Submodel":
    raise ValueError(f"parse_submodel() called on non-Submodel: {data}")

  sm = Submodel(
      sm_id=data["id"],
      id_short=data["idShort"],
      description=data.get("description", [{}])[0].get("text", ""),
      semantic_id=data.get("semanticId")
  )

  elements = {el["idShort"]: el for el in data.get("submodelElements",[])}
  processed = set()

  for id_short, elem in elements.items():
    if id_short in processed:
      continue

    unit_key = id_short + "Unit"

    if unit_key in elements:
      sm.elements.append(parse_element_with_unit(elem,elements[unit_key]))
      processed.add(id_short)
      processed.add(unit_key)
    else:
      sm.elements.append(parse_element(elem))
      processed.add(id_short)

  #for elem in data.get("submodelElements", []):
  #  sm.elements.append(parse_element(elem))

  return sm

def parse_asset_information(data):
  thumb = data.get("defaultThumbnail", {})
  return AssetInformation(
    assetKind=data["assetKind"],
    assetType=data.get("assetType"),
    globalAssetId=data.get("globalAssetId"),
    defaultThumbnail=DefaultThumbnail(
      path=thumb.get("path", ""),
      contentType=thumb.get("contentType", "")
    )
  )

def parse_aas(data):
  aas = AssetAdministrationShell(
      aas_id=data.get("id"),
      id_short=data.get("idShort"),
      assetInformation=parse_asset_information(data["assetInformation"]),
      semantic_id=data.get("semanticId")
  )

  for sm in data.get("submodels", []):
    if sm.get("type") == "ModelReference":
      continue
    if sm.get("modelType") != "Submodel":
      continue

    aas.submodels.append(parse_submodel(sm))

  return aas

def convert_aas_json_to_canon(json_string):
  data = json.loads(json_string)

  if data.get("modelType") == "AssetAdministrationShell":
      print("AAS here")
      return parse_aas(data)

  if data.get("modelType") == "Submodel":
      print("Submodel here")
      return parse_submodel(data)

  if "assetAdministrationShells" in data:
      aas_data = data["assetAdministrationShells"][0]
      aas = parse_aas(aas_data)

      if "submodels" in data:
        for sm in data.get("submodels", []):
          if sm.get("modelType") != "Submodel":
            continue
          aas.submodels.append(parse_submodel(sm))
      return aas

  raise ValueError("Unsupported JSON structure")
