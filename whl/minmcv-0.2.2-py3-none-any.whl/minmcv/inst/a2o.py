#!/usr/bin/env python3

from .canon import *
from .canon2dpp4fun import convert_canon_to_dpp4fun
from .dpp4fun2canon import convert_dpp4fun_to_canon
from .canon2json import convert_canon_to_aas_json
from .json2canon import convert_aas_json_to_canon
from .canon2yaml import convert_canon_to_aas_yaml
from .yaml2canon import convert_aas_yaml_to_canon

def json2rdf(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_dpp4fun(tCanon,export_format="xml")

def json2nt(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_dpp4fun(tCanon,export_format="nt")

def json2ttl(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_dpp4fun(tCanon,export_format="ttl")

def json2jsonld(iData):
  tCanon = convert_aas_json_to_canon(iData)
  return convert_canon_to_dpp4fun(tCanon,export_format="json-ld")

def yaml2rdf(iData):
  tCanon = convert_aas_yaml_to_canon(iData)
  return convert_canon_to_dpp4fun(tCanon,export_format="xml")









