#!/usr/bin/env python3

from .canon import *
from .canon2dpp4fun import convert_canon_to_dpp4fun
from .dpp4fun2canon import convert_dpp4fun_to_canon
from .canon2json import convert_canon_to_aas_json
from .json2canon import convert_aas_json_to_canon
from .canon2yaml import convert_canon_to_aas_yaml
from .yaml2canon import convert_aas_yaml_to_canon

def rdf2json(iData):
  tCanon = convert_dpp4fun_to_canon(iData)
  return convert_canon_to_aas_json(tCanon)

def rdf2yaml(iData):
  tCanon = convert_dpp4fun_to_canon(iData)
  return convert_canon_to_aas_yaml(tCanon)

def rdf2uml():
  print("TODO")

def rdf2xmi():
  print("TODO")
