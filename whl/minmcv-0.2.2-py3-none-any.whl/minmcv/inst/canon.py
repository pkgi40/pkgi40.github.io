#!/usr/bin/env python3

from dataclasses import dataclass, field
from typing import List, Optional, Union
from rdflib.namespace import RDF, XSD, OWL
from rdflib import Graph, Namespace, URIRef, Literal
import re

@dataclass
class SemanticId:
  semanticId_type: str
  valueType: str
  value: str 

@dataclass
class File:
  id_short: str
  mimeType: Union["image/png","image/jpeg","image/webp","application/json",
                  "application/pdf","text/html","video/mpeg"]
  value: str

@dataclass
class ReferenceElement:
  id_short: str
  value: str

@dataclass
class RelationshipElement:
  id_short: str
  first: str
  second: str

@dataclass
class Range:
  id_short: str
  valueType: Union["string","integer","double","boolean","dateTime"]
  valueMin: Union[str,None]
  valueMax: Union[str,None]
  unit: Optional[str] = None

@dataclass
class MultiLanguageProperty:
  id_short: str
  value: Union[str,None]

@dataclass
class Operation:
  id_short: str

@dataclass
class Capability:
  id_short: str

@dataclass
class Property:
  id_short: str
  valueType: Union["string","integer","double","boolean","dateTime"]
  value: Union[str,int,float,bool,None]
  unit: Optional[str] = None

@dataclass
class SubmodelElementCollection:
  id_short: Optional[str] = None
  value: List[Union["Property","File","Operation","Range","ReferenceElement",
                    "MultiLanguageProperty","SubmodelElementCollection",
                    "SubmodelElementList"]] = field(default_factory=list)
  semantic_id: Optional[str] = None

@dataclass
class SubmodelElementList:
  id_short: Optional[str] = None
  value: List[Union["Property","File","Operation","Range","ReferenceElement",
                    "MultiLanguageProperty","SubmodelElementCollection",
                    "SubmodelElementList"]] = field(default_factory=list)
  semantic_id: Optional[str] = None

@dataclass
class Submodel:
  sm_id: str
  id_short: str
  description: str
  elements: List[Union[Property,File,SubmodelElementCollection,
                    SubmodelElementList]] = field(default_factory=list)
  semantic_id: Optional[str] = None

@dataclass
class DefaultThumbnail:
  path: str
  contentType: str

@dataclass
class AssetInformation:
  assetKind: str
  assetType: str
  globalAssetId: str
  defaultThumbnail: DefaultThumbnail

@dataclass
class AssetAdministrationShell:
  aas_id: str
  id_short: str
  assetInformation: AssetInformation
  submodels: List[Submodel] = field(default_factory=list)
  semantic_id: Optional[str] = None

AAS           = Namespace("http://example.com/aas/")
DPP4FUN       = Namespace("https://www.cir4fun.eu/ontology/dpp4fun#")
DPPO          = Namespace("http://w3id.org/dppo/ontology/dpp-info/")
PDTO          = Namespace("http://www.w3id.org/pdto#")
QUDT          = Namespace("http://qudt.org/vocab/unit/")
SCHEMA        = Namespace("http://schema.org/")
GOODRELATION  = Namespace("http://purl.org/goodrelations/v1#")
DTW           = Namespace("https://w3id.org/def/dtw#")

UNIT = {
  "cm": "CentiM",
  "centimetre": "CentiM",
  "Centimetre": "CentiM",
  "g": "GM",
  "gram": "GM",
  "Gram": "GM",
  "kg": "KiloGM",
  "kilogram": "KiloGM",
  "Kilogram": "KiloGM",
  "l": "L",
  "litre": "L",
  "Litre": "L",
  "m": "Metre",
  "metre": "M",
  "Metre": "M",
  "mm": "MilliM",
  "millimetre": "MilliM",
  "Millimetre": "MilliM"
}

SUBMODEL = {
  "BillOfMaterials": DPP4FUN.BillOfMaterials,
  "Characteristics": DPP4FUN.Characteristics,
  "Nameplate": PDTO.Nameplate,
  "IntstructionInformationModel": PDTO.Nameplate,
  "AssemblyInstruction": DPP4FUN.AssemblyInstruction,
  "DisassemblyInstruction": DPP4FUN.DisassemblyInstruction,
  "DisposalInstruction": DPP4FUN.DisposalInstruction,
  "RecyclingInstruction": DPP4FUN.RecyclingInstruction,
  "RepairInstruction": DPP4FUN.RepairInstruction,
  "QualityInformationModel": PDTO.QualityInformationModel,
  "Durability": DPP4FUN.Durability,
  "Recyclability": DPP4FUN.Recyclability,
  "RegulationInformationModel": PDTO.RegulationInformationModel,
  "EnvironmentalImpact": DPP4FUN.EnvironmentalImpact,
  "HealthImpact": DPP4FUN.HealthImpact,
  "Safety": DPP4FUN.Safety,
  "Traceability": DPP4FUN.Traceability,
}

def clean_id_short(id_short: str) -> str:
    # Remove random suffix: name_number_random → name_number
    m = re.match(r"^(.*?_\d+)(?:_[A-Za-z0-9]+)$", id_short)
    if m:
        id_short =  m.group(1)
    id_short = id_short[0].upper() + id_short[1:]
    return id_short

def split_numbered_id(id_short: str):
    # Detect name_number pattern
    m = re.match(r"^(.*)_(\d+)$", id_short)
    if m:
        return m.group(1), int(m.group(2))
    return None, None

