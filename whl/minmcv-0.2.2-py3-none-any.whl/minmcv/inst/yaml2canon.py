#!/usr/bin/env python3

import yaml
from .canon import *

def parse_yaml_element(id_short, value, unit=None):
    if value in ["null", None, "None"]:
        return Property(id_short=id_short, valueType="string", value=None, unit=unit)

    if isinstance(value, bool):
        return Property(id_short=id_short, valueType="boolean", value=value, unit=unit)

    if isinstance(value, int):
        return Property(id_short=id_short, valueType="integer", value=value, unit=unit)

    if isinstance(value, float):
        return Property(id_short=id_short, valueType="double", value=value, unit=unit)

    return Property(id_short=id_short,valueType="string",value=str(value),unit=unit)

def parse_yaml_collection(id_short, mapping):
    smc = SubmodelElementCollection(id_short=id_short)

    unit_map = {}

    for k, v in mapping.items():
        if k == "Unit":
          continue
        if k.endswith("Unit"):
            base = k[:-4]
            unit_map[base] = v

    for key, val in mapping.items():
        if key.endswith("Unit"):
          smc.value.append(parse_yaml_element(key, val))

        else :
          unit = unit_map.get(key)

          if isinstance(val, dict):
              smc.value.append(parse_yaml_collection(key, val))
          else:
              smc.value.append(parse_yaml_element(key, val, unit=unit))

    return smc

def parse_yaml_list(id_short, mapping):
    smc = SubmodelElementList(id_short=id_short)

    unit_map = {}

    for k, v in mapping.items():
        if k == "Unit":
          continue
        if k.endswith("Unit"):
            base = k[:-4]
            unit_map[base] = v

    for key, val in mapping.items():
        if key.endswith("Unit"):
          smc.value.append(parse_yaml_element(key, val))

        else :
          unit = unit_map.get(key)

          if isinstance(val, dict):
              smc.value.append(parse_yaml_collection(key, val))
          else:
              smc.value.append(parse_yaml_element(key, val, unit=unit))

    return smc

def parse_yaml_submodel(data):
    sm = Submodel(
        sm_id=data["Identifier"],
        id_short=data.get("IdShort", data["Identifier"]),
        description="",
        semantic_id=None
    )

    unit_map = {}
    for k, v in data.items():
        if k == "Unit":
          continue
        
        if k.endswith("Unit"):
            base = k[:-4]
            unit_map[base] = v

    for key, val in data.items():
        if key in ["Identifier", "IdShort"]:
            continue
        if key.endswith("Unit"):
            continue

        unit = unit_map.get(key)

        if isinstance(val, dict):
          if "Set" in key:
            sm.elements.append(parse_yaml_list(key, val))
          else:
            sm.elements.append(parse_yaml_collection(key, val))
        else:
          sm.elements.append(parse_yaml_element(key, val, unit=unit))

    return sm

def parse_yaml_aas(data):
    ai = data.get("AssetInformation", {})

    asset_info = AssetInformation(
        assetKind=ai.get("assetKind","Instance"),
        assetType=ai.get("assetType",None),
        globalAssetId=ai.get("globalAssetId", ""),
        defaultThumbnail=DefaultThumbnail(
            path=ai.get("image", ""),
            contentType="image/jpeg"
        )
    )

    aas = AssetAdministrationShell(
        aas_id=data["Identifier"],
        id_short=data["IdShort"],
        assetInformation=asset_info,
        semantic_id=None
    )

    submodels = []
    for sm_block in data.get("Submodels", []):
        submodels.append(parse_yaml_submodel(sm_block))

    aas.submodels = submodels
    return aas

def convert_aas_yaml_to_canon(yaml_string):
  data = yaml.safe_load(yaml_string)
  if not isinstance(data, dict):
    raise ValueError("YAML root must be a mapping")
  return parse_yaml_aas(data)

