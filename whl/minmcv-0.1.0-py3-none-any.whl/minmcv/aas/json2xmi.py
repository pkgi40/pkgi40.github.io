#!/usr/bin/env python3

import xml.etree.ElementTree as ET
import xml.dom.minidom
import json

def build_langstring(description):
  langstring = ET.Element('AAS:LangString')
  langstring.set('value', description['text'])
  return langstring

def build_property(iId, iDescription):
  elem = ET.Element('AAS:Property')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_operation(iId, iDescription):
  elem = ET.Element('AAS:Operation')
  elem.set('xmi:id', iId)
  elem.set('base_Operation', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_file(iId, iDescription, iMimeType):
  elem = ET.Element('AAS:File')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")
  elem.set('mime_Type', f"{iMimeType}")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_range(iId, iDescription, iMin, iMax):
  elem = ET.Element('AAS:Range')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")
  elem.set('min', f"{iMin}")
  elem.set('max', f"{iMax}")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_multi_language_property(iId, iDescription):
  elem = ET.Element('AAS:MultiLanguageProperty')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_reference(iId, iDescription):
  elem = ET.Element('AAS:Property')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_entity(iId, iDescription):
  elem = ET.Element('AAS:Entity')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_capability(iId, iDescription):
  elem = ET.Element('AAS:Capability')
  elem.set('xmi:id', iId)
  elem.set('base_Property', f"{iId}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": iDescription}))
  return elem

def build_smc(smc_id, smc_description):
  elem = ET.Element('AAS:SubmodelElementCollection')
  elem.set('xmi:id', smc_id)
  elem.set('base_Class', f"{smc_id}_base")
  elem.set('base_HasKind_Class', f"{smc_id}_base")
  elem.set('base_HasSemantics_Class', f"{smc_id}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": smc_description}))
  return elem

def build_sm(sm_id_short, sm_description):
  elem = ET.Element('AAS:Submodel')
  elem.set('xmi:id', sm_id_short)
  elem.set('base_Class', f"{sm_id_short}_base")
  elem.set('base_HasKind_Class', f"{sm_id_short}_base")
  elem.set('base_HasSemantics_Class', f"{sm_id_short}_base")

  description = ET.SubElement(elem, 'description')
  description.append(build_langstring({"text": sm_description}))
  return elem

def build_nest_classifier(elems,parent, data, level=0, sml_id=None):
  child_id = data['idShort'] if sml_id is None else sml_id
  try:
    child_dp = data['description'][0]['text']
  except:
    child_dp = ""

  if data['modelType'] == 'SubmodelElementCollection': 
    child = ET.SubElement(parent, 'nestedClassifier')
    child.set('xmi:type', 'uml:Class')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_smc(child_id,child_dp)) 

    try:
      for value in data['value']:
        build_nest_classifier(elems,child,value,level+1)
    except:
      pass

  elif data['modelType'] == 'SubmodelElementList': 
    child = ET.SubElement(parent, 'nestedClassifier')
    child.set('xmi:type', 'uml:Class')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_smc(child_id,child_dp)) 

    try:
      for value in data['value']:
        build_nest_classifier(elems,child,value,level+1,child_id.replace('Set','_00'))
    except:
      pass

  elif data['modelType'] == 'Property':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] == 'Operation':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Operation')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] == 'File':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] == 'Range':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] == 'MultiLanguageProperty':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] in ['ReferenceElement','Reference']:
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 

    type_elem = ET.SubElement(child, 'type')
    type_elem.set('xmi:type', 'uml:PrimitiveType')
    type_elem.set('href',
      'pathmap://UML_LIBRARIES/XMLPrimitiveTypes.library.uml#AnyURI')
  elif data['modelType'] == 'Entity':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 
  elif data['modelType'] == 'Capability':
    child = ET.SubElement(parent, 'ownedAttribute')
    child.set('xmi:type', 'uml:Property')
    child.set('xmi:id', f"{child_id}_base")
    child.set('name', child_id)
    elems.append(build_property(child_id,child_dp)) 

def find_submodel(data):
  if isinstance(data, dict):
    if data.get('modelType') == 'Submodel':
      return data
    for key, value in data.items():
      result = find_submodel(value)
      if result is not None:
        return result
  elif isinstance(data, list):
    for item in data:
      result = find_submodel(item)
      if result is not None:
        return result
  return None

def convert_json_to_xmi(data):
  json_data = find_submodel(data)
  elems = []

  xmi = ET.Element('xmi:XMI', {
    'xmi:version': '20131001',
    'xmlns:xmi': 'http://www.omg.org/spec/XMI/20131001',
    'xmlns:AAS': 'http://www.eclipse.org/papyrus/AAS',
    'xmlns:uml': 'http://www.eclipse.org/uml2/5.0.0/UML',
    'xmlns:ecore': 'http://www.eclipse.org/emf/2002/Ecore',
    'xmlns:standard': 'http://www.eclipse.org/uml2/5.0.0/UML/Profile/Standard'
  })

  model_id = 'cea'
  sm_id = json_data["id"]
  model = ET.SubElement(xmi, 'uml:Model', {
    'URI': f"{sm_id}",
    'xmi:id': f"{model_id}_base",
    'name': 'CEA'
  })

  sm_id_short = json_data['idShort']
  try:
    sm_dp = json_data['description'][0]['text']
  except:
    sm_dp = ''
  sm = ET.SubElement(model, 'packagedElement', {
    'xmi:type': 'uml:Class',
    'xmi:id': f"{sm_id_short}_base",
    'name': json_data['idShort']
  })
  elems.append(build_sm(sm_id_short,sm_dp))

  for submodelElement in json_data['submodelElements']:
    build_nest_classifier(elems,sm,submodelElement)

  for elem in elems:
    xmi.append(elem)

  tree = ET.ElementTree(xmi)
  reparsed = xml.dom.minidom.parseString(ET.tostring(tree.getroot(),'utf-8'))

  return reparsed.toprettyxml(indent="  ")

def convertFromString(string_data): 
  return convert_json_to_xmi(json.loads(string_data)) 
