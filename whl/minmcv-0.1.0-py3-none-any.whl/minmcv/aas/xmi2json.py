#!/usr/bin/env python3

import xml.etree.ElementTree as ET
import json
import re

def parse_description(parent, text):
  parent["description"].append({
    "language": "en",
    "text": text
  })

def parse_class(parent,hierarchy,elems):
  ns = {
    'uml': 'http://www.eclipse.org/uml2/5.0.0/UML',
    'AAS': 'http://www.eclipse.org/papyrus/AAS',
    'xmi': 'http://www.omg.org/spec/XMI/20131001'
  }

  for hier in hierarchy:
    parent_id = hier.attrib.get(f"{{{ns['xmi']}}}id")
   
    for elem in elems:
      if elem.get('base') == parent_id:
         t_elem = elem

    if hier.tag == "nestedClassifier" :
      child_id = list(hier)[0].attrib.get(f"{{{ns['xmi']}}}id")
      parent_name = hier.attrib.get("name") 
      child_name = list(hier)[0].attrib.get(f"name")

      if "_00" in parent_name:
        parent.append({
          "idShort": hier.attrib.get("name"),
          "kind": "Template",
          "modelType": t_elem["modelType"] ,
          "description": [{"language":"en","text":t_elem["description"]}],
          "value": []
        })
        parse_class(parent[-1]["value"],hier,elems)
      elif "_00" in child_name:  
        parent.append({
          "idShort": hier.attrib.get("name"),
          "kind": "Template",
          "modelType": "SubmodelElementList",
          "description": [{"language":"en","text":t_elem["description"]}],
          "value": []
        })

        try:
          parse_class(parent[-1]["value"],hier,elems)
        except:
          pass
      else:
        parent.append({
          "idShort": hier.attrib.get("name"),
          "kind": "Template",
          "modelType": "SubmodelElementCollection",
          "description": [{"language":"en","text":t_elem["description"]}],
          "value": []
        })

        try:
          parse_class(parent[-1]["value"],hier,elems)
        except:
          pass
    elif "owned" in hier.tag:
      model_type = t_elem["modelType"]
      try:
        if "AnyURI" in list(hier)[0].attrib.get(f"href"): 
          model_type = "ReferenceElement"
      except:
        pass

      parent.append({
        "idShort": hier.attrib.get("name"),
        "kind": "Template",
        "modelType": model_type,
        "description": [{"language":"en","text":t_elem["description"]}]
      })

def convert_xmi_to_json(data):
  ns = {
    'uml': 'http://www.eclipse.org/uml2/5.0.0/UML',
    'AAS': 'http://www.eclipse.org/papyrus/AAS',
    'xmi': 'http://www.omg.org/spec/XMI/20131001'
  }

  root = ET.fromstring(data)
  #model = root.find("uml:Model",ns).find("packagedElement",ns)

  model = root.find("uml:Model",ns)
  if model.find("packagedElement").find("packagedElement") is not None:
    model = model.find("packagedElement",ns)


  model_id_short = model.find("packagedElement").attrib.get("name")
  model_id = "https://cea.fr/aas/submodels/" + model_id_short 

  elements = []
  prefix_aas = f"{{{ns['AAS']}}}"
  for elem in root.iter():    
    if elem.tag.startswith(prefix_aas) and "LangString" not in elem.tag:
      elem_type = elem.tag.replace(prefix_aas,'')

      try:
        elem_description = elem.find("description").attrib.get('value')
      except:
        elem_description = ""

      if "Submodel" in elem_type:
        elements.append({
          "base": elem.attrib.get("base_Class"),
          "modelType": elem_type,
          "description": elem_description
        })
      elif elem_type == "Operation":
        elements.append({
          "base": elem.attrib.get("base_Operation"),
          "modelType": elem_type,
          "description": elem_description
        })
      else: 
        elements.append({
          "base": elem.attrib.get("base_Property"),
          "modelType": elem_type,
          "description": elem_description
        })

  model_dict = {}
  for elem in elements:
    if elem.get('modelType') == "Submodel":
      model_dict = {
        "idShort": model_id_short,
        "kind": "Template",
        "modelType": elem["modelType"],
        "id": model_id,
        "description": [ {"language":"en","text":elem["description"]}],
        "submodelElements": []
      }
      parse_class(model_dict["submodelElements"],model.find("packagedElement"),
        elements)

  return json.dumps(model_dict, indent=2)

def convertFromString(string_data): 
  return convert_xmi_to_json(string_data) 
